export class Global {


  static baseURL = 'http://165.227.137.192/api/'

  static baseColor = '#fee000'

}
